setwd("C:/Users/thenu/Desktop/IT24101084_LAB9")
set.seed(123)
sample_baking_time <- rnorm(25, mean = 45, sd = 2)
print(sample_baking_time)



t_test_result <- t.test(sample_baking_time, mu = 46, alternative = "less", conf.level = 0.95)
print(t_test_result)
