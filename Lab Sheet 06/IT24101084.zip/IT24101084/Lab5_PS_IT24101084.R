setwd("C:/Users/it24101084/Desktop/IT24101084")
1 - pbinom(46, 50, 0.85, lower.tail = TRUE)
pbinom(46, 50, 0.85, lower.tail = FALSE)



dpois(15, 12)
