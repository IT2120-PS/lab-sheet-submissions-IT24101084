setwd("C:/Users/it24101084/Desktop/IT24101084 Lab 4")
branch_data <- read.table("Exercise.txt", header = TRUE)
str(branch_data)
boxplot(branch_data$Sales, main = "Sales Distribution", ylab = "Sales",outline=TRUE,col="lightblue")
fivenum(branch_data$Advertising)
IQR(branch_data$Advertising)
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)
  Q3 <- quantile(x, 0.75)
  IQR <- Q3 - Q1
  lower_bound <- Q1 - 1.5 * IQR
  upper_bound <- Q3 + 1.5 * IQR
  outliers <- x[x < lower_bound | x > upper_bound]
  return(outliers)
}
find_outliers(branch_data$Years)
