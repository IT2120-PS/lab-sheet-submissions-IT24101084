setwd("C:/Users/IT24101084/Desktop/IT24101084_Lab8")
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)
popmn<-mean(Weight)
popvar<-var(Weight)

samples<-c()
n<-c()

for(i in 1:25){
  s<-sample(Weight,6,replace = TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('s',i))
}
colnames(samples)=n
s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)
s.sd<-apply(samples,2,sd)
samplemean<-mean(s.means)
samplevars<-var(s.means)
samplesd<-sd(s.means)

popmn
samplemean

truevar=popvar/5
samplemean

